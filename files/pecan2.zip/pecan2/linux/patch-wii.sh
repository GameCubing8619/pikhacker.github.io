#!/bin/bash

echo "Welcome to the Pecan 2 installer!"

if [ -d "root" ]; then
    echo "Please remove the \"root\" folder."
    exit
fi
read -p "Press [Enter] to continue." # like "pause" on windows
echo "Extracting vanilla Pikmin 2 ISO..."
chmod +x ./wit # mark wit as executable - not needed, just in case
./wit x $1 ./root --verbose
echo "Extracted vanilla ISO."
cp "../Patch/pikmin2/message/mesres_engUS.szs" "root/files/pikmin2/message/mesres_engUS.szs"
cp "../Patch/pikmin2/new_screen/engUS/res_course_name00.szs" "root/files/pikmin2/new_screen/engUS/res_course_name00.szs"
cp "../Patch/pikmin2/new_screen/engUS/res_course_name01.szs" "root/files/pikmin2/new_screen/engUS/res_course_name01.szs"
cp "../Patch/pikmin2/new_screen/engUS/res_course_name02.szs" "root/files/pikmin2/new_screen/engUS/res_course_name02.szs"
cp "../Patch/pikmin2/new_screen/engUS/res_course_name03.szs" "root/files/pikmin2/new_screen/engUS/res_course_name03.szs"
cp "../Patch/pikmin2/new_screen/engUS/res_ground.szs" "root/files/pikmin2/new_screen/engUS/res_ground.szs"
cp "../Patch/pikmin2/new_screen/engUS/result_title_new.szs" "root/files/pikmin2/new_screen/engUS/result_title_new.szs"
cp "../Patch/pikmin2/new_screen/engUS/gameover_louie.szs" "root/files/pikmin2/new_screen/engUS/gameover_louie.szs"
cp "../Patch/pikmin2/new_screen/engUS/res_orimadown.szs" "root/files/pikmin2/new_screen/engUS/res_orimadown.szs"
cp "../Patch/pikmin2/new_screen/engUS/res_presidentdown.szs" "root/files/pikmin2/new_screen/engUS/res_presidentdown.szs"
cp "../Patch/pikmin2/new_screen/engUS/res_pikmindown.szs" "root/files/pikmin2/new_screen/engUS/res_pikmindown.szs"
cp "../Patch/pikmin2/new_screen/engUS/title.szs" "root/files/pikmin2/new_screen/engUS/title.szs"
cp "../Patch/pikmin2/new_screen/engUS/result_fuetaheta.szs" "root/files/pikmin2/new_screen/engUS/result_fuetaheta.szs"
cp "../Patch/pikmin2/new_screen/engUS/result_item.szs" "root/files/pikmin2/new_screen/engUS/result_item.szs"
cp "../Patch/pikmin2/new_screen/engUS/win_lose_reason.szs" "root/files/pikmin2/new_screen/engUS/win_lose_reason.szs"
cp "../Patch/pikmin2/new_screen/engUS/final_floor.szs" "root/files/pikmin2/new_screen/engUS/final_floor.szs"
cp "../Patch/pikmin2/new_screen/engUS/hensai_demo_kanryo.szs" "root/files/pikmin2/new_screen/engUS/hensai_demo_kanryo.szs"
cp "../Patch/pikmin2/new_screen/engUS/hensai_demo_parsent.szs" "root/files/pikmin2/new_screen/engUS/hensai_demo_parsent.szs"
cp "../Patch/pikmin2/user/Ebisawa/title/title.szs" "root/files/pikmin2/user/Ebisawa/title/title.szs"
cp "../Patch/pikmin2/user/Yamashita/arc/boot_us.szs" "root/files/pikmin2/user/Yamashita/arc/boot_us.szs"
cp "../Patch/pikmin2/opening.bnr" "root/files/pikmin2/opening.bnr"
cp "../Patch/Wii_Strap_reminder/strapA_608x456_eng.bti" "root/files/Wii_Strap_Reminder/us/bti/strapA_608x456_eng.bti" 
cp "../Patch/Wii_Strap_reminder/strapA_16_9_832x456_eng.bti" "root/files/Wii_Strap_Reminder/us/bti/strapA_16_9_832x456_eng.bti" 
cp "../Patch/Wii_Strap_reminder/strapB_608x456_eng.bti" "root/files/Wii_Strap_Reminder/us/bti/strapB_608x456_eng.bti"
cp "../Patch/Wii_Strap_reminder/us/bti/strapB_16_9_832x456_eng.bti" "root/files/Wii_Strap_Reminder/us/bti/strapB_16_9_832x456_eng.bti" 
echo "Building the new ISO..."
./wit copy ./root Pecan2_NPC.iso
rm -r ./root
echo "Done! :)"
