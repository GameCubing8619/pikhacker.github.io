Pecan 2 (Version 1.0) By: PikHacker

Pecan 2 is available for both the Wii and Gamecube versions of Pikmin 2, for Dolphin Emulator and Console.

For the Gamecube version, drop a vanilla USA or PAL(?) Pikmin 2 iso onto Patch_GC.bat

For the Wii version, drop a vanilla New Play Control Pikmin 2 USA iso onto Patch_Wii.bat
(Note: this can take a while)

Alternatively, a Riivolution patch for Pecan 2 Wii has been provided as well.
Simply use the provided R92.xml and use the Patch folder as the custom root.
Here is a good tutorial I found on using Riivolution:
https://newerteam.com/wii/help/ihashomebrew.html

Please let me know if you find typos or other problems with this hack.

Thanks for playing Pecan 2! -PikHacker