patch for the adventures of gilbert and hank

its pikmin 2 but you play as a breadbug and waterwraith, that is all
you cant actually get every treasure because some enemies wont appear
without a pikmin present, but you can at least pay off the debt in this for now.