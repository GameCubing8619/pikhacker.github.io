patch for purple and white onions in pikmin 2

simple.bat will patch your iso with only the basic files needed to make onions work, but it wont
make them actually appear in levels anywhere

full.bat edits the overworld gen files and overworld collisions to make the new onions actually appear.
only use this in combination with the vanilla game.

either way the world map onion menu and pause screen files are replaced.


This hack is intended to work as a base for hacks that want to actually balance purple and white pikmin for it.
You can use this in your own hack as long as you credit me.

I recommend you only use this with a new save file. The game can load already made save files but the 2 new onions
will act strange and pellet drops/color changing pellets will only be purple instead of random

As of 5/6/21 this mod includes functionality to add new enemies as well.
Here is the readme from that:
#Enemy Config (Version 3.0)
#To add a new enemy just increase the enemy count at the top of the file by one,
#then copy the entry of the enemy you want to the end of the file.
#Then give it a new name and index, starting at 102 for the index.
#You can control what path it gets the model, animation, parameters and
#other data from, including entirely new ones if you want your enemy to use that.
#Note that if you add new enemies you wont be able to open existing save files.
#Note if you add a new enemy the game will crash on its death unless you add it into user/abe/Pellet/pelletlist_us.szs/carcass_config.txt
#If enemy doesnt make sound effects you may need to add it to AudioRes/Key.arc
#If you add a new bulborb/dwarf bulborb with an external texture you will have to add its texture to enemyResList.txt
#and make sure if has the same name as the other of that enemy type.
#If a new enemy is added to the piklopedia, you must add new entries to user/Yamashita/zukan/us/[your map]/arc.szs/settings.ini
#Additionally an icon for it can be added to user/Yamashita/enemytex/arc.szs
#Adding text for a name or description is possible but only with extensive edits to the order of the message ids
#All enemies after the piklopedia index listed below the top of the file will have big icons.
#note the normal small icon section MUST end with a full row of 3 entries or things will break.