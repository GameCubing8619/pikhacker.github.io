Version 2.2
Pikmin 2 Multiplayer Deluxe Editon
-Made by PikHacker

To get an iso of this romhack, simply drag a Pikmin 2 .iso file onto the included .bat file.
[Linux and macOS users must chmod +x patch.sh before launching and provide the iso as an argument.]
While creating the patch, it will ask what version of the game you gave it.
Also make sure that the iso file you patch is moved to the same folder as this patcher.
Note that as of now, it is only compatible with the gamecube version of Pikmin 2.

The supported Pikmin 2 versions at the moment are:
Pikmin 2 US
Pikmin 2 PAL
Pikmin 2 JP(Citation needed)

Pikmin 2: Lands of Torture (Made by Quote Balrog)
Pikmin 2: Kaizo (Made by EBTKSPaddy)
Pikmin 2: New Year (Made by AmigaOwl)
(Choose US for these, other minor mods should work as well)

After this the installer will patch the iso with all the needed custom files.
It will then output a file called Pikmin2_4player.iso, which you can use to play the hack.

Once you've patched an iso, you're ready to go! The hack is fully compatible with 
dolphin or real hardware using homebrew tools such as Nintendont.
You can play with other people via Netplay or Parsec, or just play with actual people irl of course.
[Fullscreen Netplay Multiplayer REQUIRES the exact same patched iso to be used(including md5 hash), if you are having
trouble getting matching hashes, please review your original dumps of Pikmin 2 to ensure they are the same as well.]

[The only gecko code that is officially supported is the one used for Fullscreen Multiplayer through netplay:
04530e44 00000001
Where 0000000X is port number 1-4]
Make sure you have NO other gecko codes enabled, as they won't work with this hack
unless they're made for USA Demo 1. Even still, they may conflict with my code, so its best to not use them.

Before the title screen is a menu with a few options:
Player changes how many players are in the game, 2 3 or 4.
Punching Mode makes it so captains can punch each other for a small amount of damage.
Character Select allows you to select which character you will play as during the session. Keep in mind of the File Size
metric at the corner of the screen! Certain combinations of characters can strain available memory usage. The limit is
somewhere around 450kb, so if the File Size text turns red, you will likely encounter crashes during play.
Single Camera Cutscenes makes all other viewports dissappear whenever a cutscene plays. Its enabled by default, but if
you aren't afraid of jank then you can disable it to preserve older cutscene behavior.

In game, things should all be fully functional for all players.
Note that all players share a spray count.
All players can navigate most menus past file select.
Note that the best I could do is make it work in a sort of priority system, if player 1 is pressing no buttons,
read player 2s input, if they aren't pressing any buttons, read player 3s input, and so on.

As for side modes, challenge mode is fully functional. In fact, it skips over choosing the player count on
the menu, as that is set already. Note that I didn't bother doing much of anything for 2 player challenge 
mode, since you're better off using the normal game for that.
For now, due to how complicated it would be to make, versus mode has been disabled. This may be added in the future,
but in my opinion a 4 player versus mode is more suited to be its own full hack instead.

A large amount of issues with previous versions have been fixed, but if there are any other crashes that come about, don't
hesitate to let me know!
This is a link to my pikmin hacking server: https://discord.gg/WHSaSS5

DO NOTE: Desyncs during a netplay session can and likely will happen, make sure you aren't losing progress by ensuring
"Write Save Data" & "Sync Saves" is on during your netplay session. If you are making use of the Fullscreen Netplay
Gecko Codes, make sure you have "Sync AR/Gecko Codes" turned off so each player can make use of their individual codes.

Credits:
NerduMiner/UltimateBoboboFan: Huge help in testing and managing the project
Yoshifirebird: Helped initially getting 2 new viewports to load, helped make lighting, particle effects, and other things work in 4 viewports.
mr brocoli: First to make 4 playable captains load at once, helped make all players fill in the radar map.
People who helped playtest the hack: NerduMiner, Quote Balrog, Pat277, Untitled-1, Kai, mr brocoli, PishPish, Universal Sketch.
Credit goes to many people on different sites for the models used for characters, a more comphrensive list of who to credit
is included with Colossal Caverns

Version 2.2:
-Fixed a crash when waterwraith or the marble treasures are on-screen

Version 2.1:
-Fixed an issue on more recent dolphin builds where full-screen mode would be broken

-Fixed character icons being broken on console

-Fixed crashes when combined with New Year and going to perplexing storm