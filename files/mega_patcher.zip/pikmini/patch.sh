#!/bin/sh

ext="${1##*.}"

if [ -d "root" ]; then
    echo "Please remove the existing root folder".
    exit
fi

if [ -f "$1" ]; then
	echo "Welcome to the Pikmini installer!"
	echo "Extracting Pikmin 2 iso..."
	../nodtool.linux extract -c 2 "$1" root
	echo "iso extracted..."
	chmod -R o+rw root

	cp -f ./Patch/main.dol*				./root/sys/main.dol
	cp -f ./Patch/title.szs* 			./root/files/user/Ebisawa/title/title.szs
	cp -f ./Patch/SmallgroundCameraParms.txt	./root/files/SmallgroundCameraParms.txt
	cp -f ./Patch/SmallnaviParms.txt	./root/files/SmallnaviParms.txt
	cp -f ./Patch/SmallpikiParms.txt	./root/files/SmallpikiParms.txt
	cp -f ./Patch/opening.bnr	./root/files/opening.bnr

	echo "Now building new iso..."
	../nodtool.linux makegcn -c 2 root "Pikmini.$ext"
	rm -r root
	echo "done! :)"
	read
else
	echo "Pikmin 2 iso file not found. Please run the installer with an iso in the arguments"
	read
fi
