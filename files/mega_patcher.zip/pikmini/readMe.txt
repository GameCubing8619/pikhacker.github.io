Version 1.0
Pikmini: Pikmin 2 but everything is tiny

If Endless abyss was a test of sanity, this ones a test of patience, and also probably sanity.
The whole map is effectively huge and can take you far longer than normal to explore.
Collecting all treasures is confirmed to be possible, but it will take some clever trickery.
The main change to actual controls is that you can hold A to charge a pikmin throw, which you will
need to reach high up targets like treasures on ledges.

Some physics interactions can be janky, especially with walking up slopes, but 
it can be done with enough brute forcing.

While story mode can be fully cleared, challenge mode...
Well if any stage can be beaten that would be a cool challenge by itself.
Strange things can potentially happen when you touch the cave/geyser holes
Not sure why that is, but if you care about death count I recommend you skip the enter cave/geyser cutscenes asap

Lastly, the pellet posies on the ledge by louie on day 1 are a major pain,
you need a fully charged pikmin throw with a running start, and they need to land very near the pellet
I would definitely recommend save states for it.

Like with my other hacks, you need a copy of the pikmin 2 iso to play this.
move it to be in the same folder as this readme.
Then simply drag it onto patch.bat/.sh

It works on console and all that as usual.

Hack made by PikHacker
thanks to pish for testing this a bit
Huge thanks to ZachThePillow for having far more patience than me and 
actually playing through the entire game to confirm it can be fully cleared.