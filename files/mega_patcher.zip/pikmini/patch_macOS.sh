#!/bin/sh

home="${0%/*}"
drop="${1%/*}"
ext="${1##*.}"

if [ "$home" = "$0" ]; then
    echo "Please add \"./\" to the start of the shell script path so it is actually a filepath."
    exit
fi

if [ $# -eq 0 ] || [ "$drop" = "$1" ]; then
    echo "Please pass the filepath to a Pikmin 2 USA v1.00 *.gcm file as an argument"
	echo "HINT: If the iso is in the same folder as this script, prepend \"./\" to the iso filename."
    exit
fi

# Make sure NOD Tool is allowed to execute
cd $home
chmod +x "../nodtool.macos"
if [ $? -eq 1 ]; then
    echo "chmod +x failed."
    exit
fi

if [ -d "$drop/root" ]; then
    echo "Please remove the existing root folder".
    exit
fi

if [ -f "$1" ]; then
	echo "Welcome to the Pikmini installer!"
	echo "Extracting Pikmin 2 iso..."
	cd $home
	../nodtool.macos extract "$1" "$drop/root"
	echo "iso extracted..."
	chmod -R o+rw "$drop/root"

	cp -f $home/Patch/main.dol*				$drop/root/sys/main.dol
	cp -f $home/Patch/title.szs* 			$drop/root/files/user/Ebisawa/title/title.szs
	cp -f $home/Patch/SmallgroundCameraParms.txt	$drop/root/files/SmallgroundCameraParms.txt
	cp -f $home/Patch/SmallnaviParms.txt	$drop/root/files/SmallnaviParms.txt
	cp -f $home/Patch/SmallpikiParms.txt	$drop/root/files/SmallpikiParms.txt
	cp -f $home/Patch/opening.bnr	$drop/root/files/opening.bnr

	echo "Now building new iso..."
	../nodtool.macos makegcn "$drop/root" "$drop/Pikmini.$ext"
	rm -r "$drop/root"
	echo "done! :)"
	read
else
	echo "Pikmin 2 iso file not found. Please run the installer with an iso in the arguments"
	read
fi