v 1.0
Pikmin 2: Playable Enemies

This mod lets you control any enemy in the game!
Mostly just fun to mess around, or see what sequence breaks you
can do with the right enemies.
Playable in both 1 player and 2 players mode.
In 2 player mode, player 2 follows player one around, and can control
enemies the same way you do in single-player

pressing A B or Y will do different things depending on the enemy
press X to uncapture

To use 2 player mode, have player 2 press START during the nintendo logo
A sound effect will play to confirm it works

Day 1 cant really be played normally in 2 player mode, so its best to use 
a save file past it.

Like with my other hacks, you need a copy of the pikmin 2 iso to play this.
move it to be in the same folder as this readme.
Then simply drag it onto patch.bat/.sh

It works on console and all that as usual.

Hack made by PikHacker
Thanks to mr brocoli for testing 2-player mode