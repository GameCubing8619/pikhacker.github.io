#!/bin/sh

ext="${1##*.}"

if [ -d "root" ]; then
    echo "Please remove the existing root folder".
    exit
fi

if [ -f "$1" ]; then
	echo "Welcome to the Pikmin 2 Yellow Edition installer! v1.3"
	echo "Extracting Pikmin 2 iso..."
	../nodtool.macos extract "$1" root
	echo "iso extracted..."
	chmod -R o+rw root

	cp -f ./Patch/Start.dol*			./root/sys/main.dol
	cp -f ./Patch/boot.bin* 			./root/sys/boot.bin
	cp -f ./Patch/opening.bnr* 			./root/sys/boot.bin
	cp -r -f ./Patch/user/. 			./root/files/user
	cp -r -f ./Patch/enemy/. 			./root/files/enemy
	cp -r -f ./Patch/thp/. 				./root/files/thp
	cp -r -f ./Patch/message/. 			./root/files/message
	cp -r -f ./Patch/new_screen/. 		./root/files/new_screen

	echo "Now building new iso..."
	../nodtool.macos makegcn root "YellowEdition.$ext"
	rm -r root
	echo "done! :)"
	read
else
	echo "Pikmin 2 iso file not found. Please run the installer with an iso in the arguments"
	read
fi