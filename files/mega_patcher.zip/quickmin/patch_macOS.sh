#!/bin/sh

ext="${1##*.}"

if [ -d "root" ]; then
    echo "Please remove the existing root folder".
    exit
fi

if [ -f "$1" ]; then
	echo "Welcome to the Quickmin installer!"
	echo "Extracting Pikmin 2 iso..."
	../nodtool.macos extract "$1" root
	echo "iso extracted..."
	chmod -R o+rw root

	cp -f ./Patch/main.dol*				./root/sys/main.dol
	cp -f ./Patch/defaultgen.txt* 			./root/files/user/Abe/map/Tutorial/defaultgen.txt
	cp -f ./Patch/message_window.szs	./root/files/new_screen/eng/message_window.szs
	cp -f ./Patch/res_ground.szs	./root/files/new_screen/eng/res_ground.szs
	cp -f ./Patch/res_cave.szs	./root/files/new_screen/eng/res_cave.szs
	cp -f ./Patch/QuicknaviParms.txt	./root/files/QuicknaviParms.txt
	cp -f ./Patch/QuickpikiParms.txt	./root/files/QuickpikiParms.txt
	cp -f ./Patch/opening.bnr	./root/files/opening.bnr

	echo "Now building new iso..."
	../nodtool.macos makegcn root "Quickmin.$ext"
	rm -r root
	echo "done! :)"
	read
else
	echo "Pikmin 2 iso file not found. Please run the installer with an iso in the arguments"
	read
fi