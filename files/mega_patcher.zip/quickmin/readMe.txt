Version 1.0
Quikmin: Pikmin 2 but everything is super fast

If pikmini was too slow for you (it probably was)
heres the opposite to make up for it! No, not giant everything,
thats a lot more unplayable than it sounds.
This hack makes all enemies, pikmin, and objects move at double speed
As well as completely removes pretty much all cutscenes and makes menus
far quicker.
It also uses the treaure collected message from colossal caverns, which is neat.
(Ignore it looked wrong in the trailer footage)
In general it makes the game a lot more action packed, and less slow to start.
Some bosses are a LOT harder at double speed, but thats part of the challenge!
I have'nt tested it, but if you know your way around file replacing you could definitely
combine this with lands of torture or Kaizo, for quite the challenge to say the least.

Note that a lot of the usual opportunities to save the game are gone, you can only 
save during cave entry and when you repay the debt. Regardless this can be played with 
normal save files and should  be fine.
You can play challenge mode in this, although most of the cutscenes arent removed.
You can skip to sunset on day 1 in this, youll need it

Like with my other hacks, you need a copy of the pikmin 2 iso to play this.
move it to be in the same folder as this readme.
Then simply drag it onto patch.bat/.sh

It works on console and all that as usual.

Hack made by PikHacker
Thanks to quote balrog for testing