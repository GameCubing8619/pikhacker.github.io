#!/bin/sh

ext="${1##*.}"

if [ -d "root" ]; then
    echo "Please remove the existing root folder".
    exit
fi

if [ -f "$1" ]; then
	echo "Welcome to the Pikmin 2 Multiplayer Deluxe installer!"
	echo "Extracting Pikmin 2 iso..."
	../nodtool.linux extract -c 2 "$1" root
	echo "iso extracted..."
	chmod -R o+rw root

	cp -f ./Patch/main.dol*				./root/sys/main.dol
	cp -r -f ./Patch/player/. 			./root/files/player
	cp -r -f ./Patch/eng/. 				./root/files/new_screen/eng
	cp -r -f ./Patch/eng/. 				./root/files/new_screen/jpn
	cp -r -f ./Patch/eng/. 				./root/files/new_screen/spa
	cp -r -f ./Patch/eng/. 				./root/files/new_screen/fra
	cp -r -f ./Patch/eng/. 				./root/files/new_screen/ger
	cp -f ./Patch/opening.bnr* 			./root/files/opening.bnr
	cp -f ./Patch/pikis.szs* 			./root/files/user/Kando/piki/pikis.szs

	echo "Now building new iso..."
	../nodtool.linux makegcn -c 2 root "Pikmin2_4player.$ext"
	rm -r root
	echo "done! :)"
	read
else
	echo "Pikmin 2 iso file not found. Please run the installer with an iso in the arguments"
	read
fi