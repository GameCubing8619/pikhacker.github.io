#!/bin/sh

home="${0%/*}"
drop="${1%/*}"
ext="${1##*.}"

if [ "$home" = "$0" ]; then
    echo "Please add \"./\" to the start of the shell script path so it is actually a filepath."
    exit
fi

if [ $# -eq 0 ] || [ "$drop" = "$1" ]; then
    echo "Please pass the filepath to a Pikmin 2 USA v1.00 *.gcm file as an argument"
	echo "HINT: If the iso is in the same folder as this script, prepend \"./\" to the iso filename."
    exit
fi

# Make sure NOD Tool is allowed to execute
cd $home
chmod +x "../nodtool.macos"
if [ $? -eq 1 ]; then
    echo "chmod +x failed."
    exit
fi

if [ -d "$drop/root" ]; then
    echo "Please remove the existing root folder".
    exit
fi

if [ -f "$1" ]; then
	echo "Welcome to the Pikmin 2 Multiplayer Deluxe installer!"
	echo "Extracting Pikmin 2 iso..."
	cd $home
	../nodtool.macos extract "$1" "$drop/root"
	echo "iso extracted..."
	chmod -R o+rw "$drop/root"

	cp -f $home/Patch/main.dol*				$drop/root/sys/main.dol
	cp -r -f $home/Patch/player/. 			$drop/root/files/player
	cp -r -f $home/Patch/eng/. 				$drop/root/files/new_screen/eng
	cp -r -f $home/Patch/eng/. 				$drop/root/files/new_screen/jpn
	cp -r -f $home/Patch/eng/. 				$drop/root/files/new_screen/spa
	cp -r -f $home/Patch/eng/. 				$drop/root/files/new_screen/fra
	cp -r -f $home/Patch/eng/. 				$drop/root/files/new_screen/ger
	cp -f $home/Patch/opening.bnr* 			$drop/root/files/opening.bnr
	cp -f $home/Patch/pikis.szs* 			$drop/root/files/user/Kando/piki/pikis.szs

	echo "Now building new iso..."
	cd $home
	../nodtool.macos makegcn "$drop/root" "$drop/Pikmin2_4player.$ext"
	rm -r "$drop/root"
	echo "done! :)"
	read
else
	echo "Pikmin 2 iso file not found. Please run the installer with an iso in the arguments"
	read
fi