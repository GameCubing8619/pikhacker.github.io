Source model taken from here https://www.models-resource.com/playstation_2/shinmegamitenseiiiinocturne/model/10215/

Source audio taken from here https://www.youtube.com/watch?v=qO6LWQhvzRw

Source image taken from here https://www.reddit.com/r/Megaten/comments/bc8rtg/who_me_the_demifiend_with_the_moustache_and_crazy/