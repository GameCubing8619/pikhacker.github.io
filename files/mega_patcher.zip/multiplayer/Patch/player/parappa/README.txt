Original model ripped by auxfox at: https://www.models-resource.com/playstation_2/parappatherapper2/model/8655/
Original icon created by Manfred Von Karma at: https://commons.wikimedia.org/wiki/File:PaRappa_the_Rapper_Head_Basic_Vector_Art.png
Original theme from: https://www.youtube.com/watch?v=LIyibFd6WaA