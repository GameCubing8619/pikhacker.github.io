Version 1.2
Pikmin 2 but its a randomly generated infinite cave

how far can you go before losing your sanity?

more enemies will appear over time, boss floors and rest 
floors can randomly appear, thats about it.
Consider it like a tech demo for something I want to add to the eventual Colossal Caverns Deluxe edition.
That version will be a lot more involved with things like a shop and more unique cave themes.

Like with my other hacks, you need a copy of the pikmin 2 iso to play this.
move it to be in the same folder as this readme.
Then simply drag it onto patch.bat/.sh

You maaaay get crashes on floors starting in like the 70s if you're on console 
or on Dolphin with normal memory size. If you can use extra memory, that should fix it.
Otherwise let me know on discord. I highly recommend you join my discord server if 
you play anything Ive made.

Theres still stuff I want to add to this hack eventually, so it will likely recieve updates to come

https://discord.gg/WHSaSS5

Hack made by PikHacker
-testing help from Universal Sketch, ZachThePillow, AmigaOwl, and Sleepy

-----------------------------------------------------------------------------------------------------------
Endless Abyss 1.2

-Fixed a random softlock where you spawn in two titan dweevil rooms with no exit

-The waterwraith no longer appears outside of boss fights, it was a funny easter egg,
but often caused crashes from memory use.

-Fixed an issue where all floors past 220 are rest floors
-----------------------------------------------------------------------------------------------------------
Endless Abyss 1.1

-Fixed floors rarely missing holes (itemless dead ends are gone)

-Fixed infinite loading screen on later floors

-Fixed purple/white candypop buds not spawning when you have too many of their color

-Fixed current floor breaking when resetting after floor 128

-Fixed the UI not showing all digits of the floor past the hundreds

-Queen candypop buds can now randomly appear on any floor

-Bulbmin can rarely appear on any floor starting in the 30s

-The swamp cave theme is only half as common as the others.

-File select menu now properly shows the treasure and poko count

-Fixed plants in boss arenas being wrong

-Red and Hairy bulborbs were swapped in their tier

-Boss and rest floors are both slightly more common

-You can now press Start during the nintendo logo to access
 the title screen, where you can adjust options if you need to
 
-You can now skip treasure cutscenes in the same way as 251

-A geyser now spawns on floor 4,294,967,295. This is the
	highest possible value the game can handle.
	
-Candypop bud spawn rates in general have been adjusted,
	white is no longer more common than the others

-End cap enemy spawns can be set to fall more often