#!/bin/sh

ext="${1##*.}"

if [ -d "root" ]; then
    echo "Please remove the existing root folder".
    exit
fi

if [ -f "$1" ]; then
	echo "Welcome to the Pikmin 2 Endless Abyss Demo installer!"
	echo "Extracting Pikmin 2 iso..."
	../nodtool.macos extract "$1" root
	echo "iso extracted..."
	chmod -R o+rw root

	cp -f ./Patch/main.dol*				./root/sys/main.dol
	cp -f ./Patch/mesres_eng.szs* 			./root/files/message/mesRes_eng.szs
	cp -f ./Patch/boot.bin* 			./root/sys/boot.bin
	cp -f ./Patch/memorycardheader.szs	./root/files/memoryCard/memorycardheader.szs
	cp -r -f ./Patch/unit/. 				./root/files/user/Mukki/mapunits/units

	echo "Now building new iso..."
	../nodtool.macos makegcn root "Pikmin2EA.$ext"
	rm -r root
	echo "done! :)"
	read
else
	echo "Pikmin 2 iso file not found. Please run the installer with an iso in the arguments"
	read
fi